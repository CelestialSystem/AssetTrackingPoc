﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using System.IO;

namespace LoginAPIService
{
   // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
   // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
   public class Service1 : IService1
   {
      public string GetData(int value)
      {
         return string.Format("You entered: {0}", value);
      }

      public CompositeType GetDataUsingDataContract(CompositeType composite)
      {
         if (composite == null)
         {
            throw new ArgumentNullException("composite");
         }
         if (composite.BoolValue)
         {
            composite.StringValue += "Suffix";
         }
         return composite;
      }

      public string login(string username, string password)
      {
         //HttpClient client = new HttpClient();
         //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


         //HttpResponseMessage response = await client.GetAsync("http://somedomain.com/serviceAddress");

         //string responseContent = await response.Content.ReadAsStringAsync();

         //return responseContent;
         ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

         string url = "http://3.221.119.221:4000/login";
         string result = string.Empty;
         var httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
         httpWebRequest.ContentType = "application/json";
         httpWebRequest.Method = "POST";

         //X509Certificate certificate = GetClientCertificate(certPath);
         //httpWebRequest.ClientCertificates.Add(certificate);

         using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
         {
            List<object> objList = new List<object>();

            // string jsonData = "{\"data\":{\"email\":\"ashwinik@yopmail.com\",\"password\":\"Cel@1234\"}}";
            string jsonData = "{\"email\":\"ashwinik@yopmail.com\",\"password\":\"Cel@1234\"}";

            streamWriter.Write(jsonData);
            streamWriter.Flush();
            //streamWriter.Write(json);
         }
         // httpWebRequest.Headers = jsonData;
         var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
         using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
         {
            result = streamReader.ReadToEnd();
         }
         return result;
      }
   }
}
