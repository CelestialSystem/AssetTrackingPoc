const prodPORT = 3000;
// const serverURL = 'dev-int-ewa.csi-infra.com';
const serverURL = '3.221.119.221';
const serverPORT = '4000';
export { prodPORT, serverPORT, serverURL };
